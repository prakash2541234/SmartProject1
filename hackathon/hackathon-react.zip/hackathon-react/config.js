// Runtime configuration — replace LOGIC_APP_URL value on the server
// without needing to rebuild the React app.
// On Azure App Service, update this file or use a startup script to inject the real URL.
window._env_ = {
  LOGIC_APP_URL: "https://logicapp-001-bxhxa3g4eyfkfjds.centralindia-01.azurewebsites.net:443/api/hackathon/triggers/When_an_HTTP_request_is_received/invoke?api-version=2022-05-01&sp=%2Ftriggers%2FWhen_an_HTTP_request_is_received%2Frun&sv=1.0&sig=nnIGjORM42bDVzU2DrIuw5eL9pnli8mQA30ZErhHv8w"
};
