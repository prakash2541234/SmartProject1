// Runtime configuration — replace LOGIC_APP_URL value on the server
// without needing to rebuild the React app.
// On Azure App Service, update this file or use a startup script to inject the real URL.
window._env_ = {
  LOGIC_APP_URL: "https://arch-lenscopilot-d4beaah3dqh7fcgp.centralindia-01.azurewebsites.net:443/api/ArchLensCopilot/triggers/When_an_HTTP_request_is_received/invoke?api-version=2022-05-01&sp=%2Ftriggers%2FWhen_an_HTTP_request_is_received%2Frun&sv=1.0&sig=2UsQCBqVDreQwRogFqWtxIUctZH-MBViuZ07Qkh0qFc",
  FILTER_SUBSCRIPTIONS_URL: "https://archlens-copilot-a6cjahanhbc6hxfg.centralindia-01.azurewebsites.net/api/filter_subscriptions?code=aC3rAY0gkauNXS8blw9E2hrKqYhmijXF8EJkdLdkbXzfAzFu8C4cnw=="
};
