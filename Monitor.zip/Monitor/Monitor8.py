#monitor 8 - store monitor outputs in Azure Table Storage

import logging
import json
import os
from datetime import datetime
import azure.functions as func
from azure.data.tables import TableServiceClient

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Monitor_8 function triggered")

    try:
        # Read request body
        req_body = req.get_json()

        # ✅ Extract correct keys from payload
        request_params = req_body.get("request_parameters", {})

        ritm_num = request_params.get("ritm_number", "unknown")
        catalog_sysid = request_params.get("catalog_task_sysid", "unknown")

        # ✅ Debug logs
        logging.info(f"PartitionKey (ritm_num): {ritm_num}")
        logging.info(f"RowKey (catalog_sysid): {catalog_sysid}")

        # Extract monitor outputs

        # ✅ Get connection string (with fallback)
        connection_string = os.getenv("TABLE_STORAGE_CONNECTION_STRING")

        if not connection_string:
            logging.warning("Using fallback connection string")

            # ⚠️ IMPORTANT: Replace this with your FULL correct connection string
            connection_string = "DefaultEndpointsProtocol=https;AccountName=subscriptioncreation;AccountKey=FxlHySGVXafXxHZRKs+9yZR06N4yMGjlXtHNe39ulajMmj5lR9sB2mJAvZqPX4AEaL/FZ95LjIIv+AStkOHRUg==;EndpointSuffix=core.windows.net"

        # Optional debug
        logging.info(f"Connection string length: {len(connection_string)}")

        # Table name
        table_name = os.getenv(
            "TABLE_STORAGE_MONITOR_TABLE_NAME",
            "subscriptioncreation"
        )

        logging.info(f"Using table: {table_name}")

        # Connect to Table Storage
        service = TableServiceClient.from_connection_string(conn_str=connection_string)
        service.create_table_if_not_exists(table_name=table_name)
        table_client = service.get_table_client(table_name)

        # ✅ Create entity
        entity = {
            "PartitionKey": ritm_num,
            "RowKey": catalog_sysid,
            "StoredTimestamp": datetime.utcnow().isoformat()
        }

        # ✅ Use UPSERT (prevents duplicate conflict error)
        table_client.upsert_entity(entity=entity)

        logging.info("Entity inserted/updated successfully")

        return func.HttpResponse(
            "Monitor data stored successfully",
            status_code=200
        )

    except Exception as e:
        logging.error(f"Error: {str(e)}")

        return func.HttpResponse(
            f"Error storing monitor data: {str(e)}",
            status_code=500
        )