import json
import os
import logging
import azure.functions as func
from azure.data.tables import TableServiceClient, UpdateMode


# -------------------------------
# Helpers
# -------------------------------

def is_missing(value):
    return value is None or value == ""


def ensure_dict(value):
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            return json.loads(value)
        except Exception:
            return {}
    return {}


# -------------------------------
# Validation Logic
# -------------------------------

def validate_sp_forward(data: dict) -> dict:
    result = {
        "status": "success",
        "failed_at": "",
        "root_cause": "",
        "message": "",
        "details": {}
    }

    raw_is_sp_requested = data.get("IsSPRequested", data.get("IsSPRequest"))
    if raw_is_sp_requested is None:
        req_params_for_flag = ensure_dict(
            ensure_dict(data.get("create_sp_input")).get("request_parameters")
        )
        raw_is_sp_requested = req_params_for_flag.get(
            "IsSPRequested", req_params_for_flag.get("IsSPRequest")
        )

    if isinstance(raw_is_sp_requested, str):
        is_sp_requested = raw_is_sp_requested.strip().lower() == "true"
    else:
        is_sp_requested = bool(raw_is_sp_requested)

    if not is_sp_requested:
        return {
            "status": "failed",
            "failed_at": "SP_REQUEST_CHECK",
            "root_cause": "SP_NOT_REQUESTED",
            "message": "Service principal is not requested",
            "details": {
                "IsSPRequested": raw_is_sp_requested
            }
        }

    sp_status = data.get("sp_status")
    sp_name = data.get("sp_name")

    create_input = ensure_dict(data.get("create_sp_input"))
    create_output = ensure_dict(data.get("create_sp_response"))
    parse_output = ensure_dict(data.get("parse_sp_output"))

    sp_params = ensure_dict(create_input.get("sp_parameters"))
    req_params = ensure_dict(create_input.get("request_parameters"))

    # ✅ SUCCESS CASE
    if sp_status == "success" and not is_missing(sp_name):
        result["message"] = "SP created successfully"
        result["details"] = {"sp_name": sp_name}
        return result

    # -------------------------------
    # INPUT VALIDATION
    # -------------------------------
    required_inputs = {
        "application_id": sp_params.get("application_id"),
        "environment": sp_params.get("environment"),
        "subscription_id": sp_params.get("subscription_id"),
        "subscription_role": sp_params.get("subscription_role"),
        "sp_owners": req_params.get("sp_owners")
    }

    missing_inputs = [
        key for key, val in required_inputs.items() if is_missing(val)
    ]

    if missing_inputs:
        return {
            "status": "failed",
            "failed_at": "CREATE_SP_INPUT",
            "root_cause": "MISSING_INPUT",
            "message": f"Missing required input fields: {missing_inputs}",
            "details": {"missing_fields": missing_inputs}
        }

    # -------------------------------
    # CREATE SP API CHECK
    # -------------------------------
    create_status = create_output.get("statusCode")

    if create_status != 200:
        return {
            "status": "failed",
            "failed_at": "CREATE_SP_API",
            "root_cause": "API_FAILURE",
            "message": "CreateSP API failed",
            "details": {
                "statusCode": create_status,
                "response": create_output
            }
        }

    # -------------------------------
    # PARSE OUTPUT CHECK
    # -------------------------------
    parsed_status = parse_output.get("status")
    parsed_sp_name = ensure_dict(parse_output.get("details")).get("sp_name")

    if is_missing(parsed_status) or is_missing(parsed_sp_name):
        return {
            "status": "failed",
            "failed_at": "PARSE_SP_OUTPUT",
            "root_cause": "INVALID_RESPONSE_FORMAT",
            "message": "ParseSPOutput missing required fields",
            "details": {"parse_output": parse_output}
        }

    # -------------------------------
    # FINAL MAPPING FAILURE
    # -------------------------------
    return {
        "status": "failed",
        "failed_at": "SET_SP_STATUS",
        "root_cause": "MAPPING_FAILED",
        "message": "SetSPStatus mapping failed",
        "details": {
            "expected_sp_name": parsed_sp_name,
            "actual_sp_name": sp_name
        }
    }


# -------------------------------
# Extract request params (FIXED)
# -------------------------------

def _extract_request_params(body: dict) -> dict:
    original_payload = ensure_dict(body.get("original_payload"))

    candidates = [
        {
            "ritm_number": body.get("ritm_number"),
            "catalog_task_sysid": body.get("catalog_task_sysid"),
        },
        body.get("request_parameters", {}),
        ensure_dict(body.get("create_sp_input")).get("request_parameters", {}),
        ensure_dict(body.get("parse_sp_output")).get("request_parameters", {}),
        ensure_dict(body.get("create_sp_response")).get("request_parameters", {}),
        ensure_dict(body.get("trigger_payload")).get("request_parameters", {}),
        original_payload.get("request_parameters", {})  # ✅ IMPORTANT FIX
    ]

    for candidate in candidates:
        if (
            isinstance(candidate, dict)
            and candidate.get("ritm_number")
            and candidate.get("catalog_task_sysid")
        ):
            return candidate

    return {}


# -------------------------------
# Store result in Table Storage (FIXED)
# -------------------------------

def store_monitor_result(ritm_number: str, catalog_task_sysid: str, result: dict) -> None:
    connection_string = os.getenv("TABLE_STORAGE_CONNECTION_STRING", "DefaultEndpointsProtocol=https;AccountName=subscriptioncreation;AccountKey=FxlHySGVXafXxHZRKs+9yZR06N4yMGjlXtHNe39ulajMmj5lR9sB2mJAvZqPX4AEaL/FZ95LjIIv+AStkOHRUg==;EndpointSuffix=core.windows.net")
    table_name = os.getenv("TABLE_STORAGE_MONITOR_TABLE_NAME", "subscriptioncreation")

    if not connection_string:
        raise ValueError("Missing TABLE_STORAGE_CONNECTION_STRING")

    if not ritm_number or not catalog_task_sysid:
        raise ValueError("PartitionKey or RowKey is missing")

    service = TableServiceClient.from_connection_string(conn_str=connection_string)
    table_client = service.get_table_client(table_name)

    entity = {
        "PartitionKey": str(ritm_number),
        "RowKey": str(catalog_task_sysid),
        "Monitor3": json.dumps(result)
    }

    table_client.upsert_entity(entity=entity, mode=UpdateMode.MERGE)

    logging.info(f"Stored Monitor3 result for {ritm_number} / {catalog_task_sysid}")


# -------------------------------
# MAIN FUNCTION
# -------------------------------

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        try:
            body = req.get_json()
        except Exception as e:
            return func.HttpResponse(
                json.dumps({
                    "status": "failed",
                    "error": "INVALID_JSON",
                    "message": str(e)
                }),
                status_code=400,
                mimetype="application/json"
            )

        # ✅ Extract IDs safely
        request_params = _extract_request_params(body)
        ritm_number = request_params.get("ritm_number")
        catalog_task_sysid = request_params.get("catalog_task_sysid")

        # ✅ Validate flow
        result = validate_sp_forward(body)

        # ✅ Store in Table Storage
        store_monitor_result(ritm_number, catalog_task_sysid, result)

        response_status_code = 200 if result.get("status") == "success" else 400

        return func.HttpResponse(
            json.dumps(result, indent=2),
            status_code=response_status_code,
            mimetype="application/json"
        )

    except Exception as e:
        logging.exception("Monitor-3 failure")

        return func.HttpResponse(
            json.dumps({
                "status": "failed",
                "error": "INTERNAL_SERVER_ERROR",
                "message": str(e)
            }),
            status_code=500,
            mimetype="application/json"
        )