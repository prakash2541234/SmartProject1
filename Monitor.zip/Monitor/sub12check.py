#monitor 2 - validate subscription creation flow and store results in Table Storage

import json
import os
import logging
import azure.functions as func
from azure.data.tables import TableServiceClient, UpdateMode


def store_monitor_result(ritm_number: str, catalog_task_sysid: str, result: dict) -> None:
    connection_string = os.getenv(
        "TABLE_STORAGE_CONNECTION_STRING",
        "DefaultEndpointsProtocol=https;AccountName=subscriptioncreation;AccountKey=FxlHySGVXafXxHZRKs+9yZR06N4yMGjlXtHNe39ulajMmj5lR9sB2mJAvZqPX4AEaL/FZ95LjIIv+AStkOHRUg==;EndpointSuffix=core.windows.net"
    )
    table_name = os.getenv("TABLE_STORAGE_MONITOR_TABLE_NAME", "subscriptioncreation")

    service = TableServiceClient.from_connection_string(conn_str=connection_string)
    table_client = service.get_table_client(table_name)

    entity = {
        "PartitionKey": ritm_number,
        "RowKey": catalog_task_sysid,
        "Monitor2": json.dumps(result)
    }

    table_client.upsert_entity(entity=entity, mode=UpdateMode.MERGE)
    logging.info(f"Monitor2 result stored for ritm={ritm_number}, catalog_sysid={catalog_task_sysid}")


def _extract_request_params(body: dict) -> dict:
    candidates = [
        body.get("request_parameters", {}),
        body.get("create_payload_response", {}).get("request_parameters", {}),
        body.get("createsub_workflow_input", {}).get("request_parameters", {}),
        body.get("parsed_payload", {}).get("request_parameters", {}),
        body.get("trigger_payload", {}).get("request_parameters", {}),
    ]

    for candidate in candidates:
        if isinstance(candidate, dict) and candidate.get("ritm_number") and candidate.get("catalog_task_sysid"):
            return candidate

    for candidate in candidates:
        if isinstance(candidate, dict) and candidate:
            return candidate

    return {}


def _determine_status_code(result: dict) -> int:
    if result.get("errors"):
        return 400

    def _safe_status(value):
        return value.get("status") if isinstance(value, dict) else None

    subscription_name_status = _safe_status(result.get("subscription_name"))
    create_sub_status = _safe_status(result.get("createSub_input"))
    parse_status = _safe_status(result.get("parse_output"))
    http1_status = _safe_status(result.get("http1_checked"))

    if subscription_name_status == "MISSING":
        return 400

    if create_sub_status == "OK":
        return 200

    if parse_status == "OK":
        return 200

    if http1_status == "OK":
        return 200

    return 400


def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        body = req.get_json()

        request_params = _extract_request_params(body)
        ritm_number = request_params.get("ritm_number", "unknown")
        catalog_task_sysid = request_params.get("catalog_task_sysid", "unknown")

        result = {
            "subscription_name": None,
            "createSub_input": None,
            "parse_output": None,
            "http1_checked": False,
            "errors": []
        }

        create_payload_response = body.get("create_payload_response")
        if not isinstance(create_payload_response, dict):
            create_payload_response = {}

        sub_name = create_payload_response.get("subscription_name") or create_payload_response.get("subscription_id")

        # subscription_name is informational only; do not gate downstream checks on it
        if sub_name:
            result["subscription_name"] = {
                "status": "OK",
                "value": sub_name
            }
        else:
            result["subscription_name"] = {
                "status": "MISSING",
                "value": None
            }

        # Step 2: Check createSub workflow input
        create_sub = body.get("createsub_workflow_input")

        if not create_sub:
            result["createSub_input"] = {
                "status": "MISSING",
                "value": None
            }
            result["errors"].append("createSub workflow input missing")

            # Step 3: Check parsed payload
            parsed = body.get("parsed_payload")

            if not parsed or not parsed.get("subscription_name"):
                result["parse_output"] = {
                    "status": "MISSING",
                    "value": None
                }
                result["errors"].append("parsed_payload invalid")

                # Step 4: Final fallback → http1 check
                http1 = body.get("trigger_payload")

                if not http1:
                    result["http1_checked"] = {
                        "status": "MISSING",
                        "value": None
                    }
                    result["errors"].append("http1 payload missing")
                else:
                    result["http1_checked"] = {
                        "status": "OK",
                        "value": http1
                    }

            else:
                result["parse_output"] = {
                    "status": "OK",
                    "value": parsed.get("subscription_name")
                }

        else:
            result["createSub_input"] = {
                "status": "OK",
                "value": create_sub
            }

        status_code = _determine_status_code(result)
        store_monitor_result(ritm_number, catalog_task_sysid, result)
        return func.HttpResponse(
            json.dumps(result),
            status_code=status_code
        )

    except Exception as e:
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            status_code=500
        )