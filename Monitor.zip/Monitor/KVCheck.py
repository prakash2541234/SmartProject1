#monitor 6 - validate KV creation flow and store results in Table Storage

import json
import os
import logging
import azure.functions as func
from azure.data.tables import TableServiceClient, UpdateMode


def is_missing(value):
    return value is None or value == ""


def ensure_dict(value):
    if isinstance(value, dict):
        return value

    if isinstance(value, str):
        try:
            return json.loads(value)
        except Exception:
            return {}

    return {}


def validate_kv(data: dict) -> dict:
    result = {
        "status": "success",
        "errors": [],
        "missing_fields": {},
        "details": {}
    }

    # ==========================================
    # 🔹 Extract Inputs
    # ==========================================
    kv_status = data.get("kv_status")
    kv_name = data.get("kv_name")

    raw_kv_response = ensure_dict(data.get("raw_kv_response"))
    parsed_kv_output = ensure_dict(data.get("parsed_kv_output"))
    input_payload = ensure_dict(data.get("input_payload"))

    subscription_id = input_payload.get("subscription_id")
    appid = input_payload.get("appid")
    environment = input_payload.get("environment")
    region = input_payload.get("region")

    # ==========================================
    # 🔹 Step 1: Validate KV Output (Final Step)
    # ==========================================
    if is_missing(kv_status) or kv_status != "success":
        result["status"] = "failed"

        if is_missing(kv_status):
            result["errors"].append("kv_status is missing")
        else:
            result["errors"].append(f"KV creation failed with status: {kv_status}")

        if is_missing(kv_name):
            result["errors"].append("keyvault_name is missing")
            result["missing_fields"]["kv_name"] = True

        # ==========================================
        # 🔹 Step 2: Check Parsed KV Output
        # ==========================================
        parse_status = parsed_kv_output.get("status")
        parse_message = parsed_kv_output.get("message")

        if is_missing(parse_status) or is_missing(parse_message):
            result["errors"].append(
                "ParseKVOutput failed to receive proper data from CreateKV function"
            )
            result["missing_fields"]["parsed_kv_output"] = True

        else:
            result["errors"].append(
                "KV step failed to map values from ParseKVOutput"
            )
            result["details"]["issue"] = "KV_MAPPING_FAILED"
            return result

        # ==========================================
        # 🔹 Step 3: Check Raw KV Response
        # ==========================================
        raw_status = raw_kv_response.get("status")
        raw_message = raw_kv_response.get("message")

        if not is_missing(raw_status) and not is_missing(raw_message):
            result["errors"].append(
                "ParseKVOutput failed to map data from CreateKV response"
            )
            result["details"]["issue"] = "PARSE_MAPPING_FAILED"
            return result

        result["errors"].append("CreateKV function did not return proper response")
        result["missing_fields"]["raw_kv_response"] = True

        # ==========================================
        # 🔹 Step 4: Validate Input Payload
        # ==========================================
        fields = {
            "subscription_id": subscription_id,
            "appid": appid,
            "environment": environment,
            "region": region
        }

        for key, value in fields.items():
            if is_missing(value):
                result["missing_fields"][key] = True
                result["errors"].append(f"{key} is missing")
            else:
                result["missing_fields"][key] = False

        if any(result["missing_fields"].values()):
            result["errors"].append(
                "CreateKV failed due to invalid input payload"
            )
            result["details"]["issue"] = "INPUT_PAYLOAD_FAILED"
        else:
            result["errors"].append(
                "CreateKV execution failed even though input payload is correct"
            )
            result["details"]["issue"] = "CREATE_KV_FAILED"

    # ==========================================
    # 🔹 Success Case
    # ==========================================
    else:
        result["details"]["message"] = "KeyVault created successfully"
        result["details"]["kv_name"] = kv_name

    # ==========================================
    # 🔹 Always Attach Debug Info
    # ==========================================
    result["details"]["debug"] = {
        "kv_status": kv_status,
        "kv_name": kv_name,
        "parsed_kv_output": parsed_kv_output,
        "raw_kv_response": raw_kv_response,
        "input_payload": input_payload
    }

    return result


def store_monitor_result(ritm_number: str, catalog_task_sysid: str, result: dict) -> None:
    connection_string = os.getenv(
        "TABLE_STORAGE_CONNECTION_STRING",
        "DefaultEndpointsProtocol=https;AccountName=subscriptioncreation;AccountKey=FxlHySGVXafXxHZRKs+9yZR06N4yMGjlXtHNe39ulajMmj5lR9sB2mJAvZqPX4AEaL/FZ95LjIIv+AStkOHRUg==;EndpointSuffix=core.windows.net"
    )
    table_name = os.getenv("TABLE_STORAGE_MONITOR_TABLE_NAME", "subscriptioncreation")

    service = TableServiceClient.from_connection_string(conn_str=connection_string)
    table_client = service.get_table_client(table_name)

    entity = {
        "PartitionKey": ritm_number,
        "RowKey": catalog_task_sysid,
        "Monitor6": json.dumps(result)
    }

    table_client.upsert_entity(entity=entity, mode=UpdateMode.MERGE)
    logging.info(f"Monitor6 result stored for ritm={ritm_number}, catalog_sysid={catalog_task_sysid}")


def _extract_request_params(body: dict) -> dict:
    parsed_kv_output = ensure_dict(body.get("parsed_kv_output"))
    raw_kv_response = ensure_dict(body.get("raw_kv_response"))
    input_payload = ensure_dict(body.get("input_payload"))
    trigger_payload = ensure_dict(body.get("trigger_payload"))
    create_kv_input = ensure_dict(body.get("create_kv_input"))
    create_kv_response = ensure_dict(body.get("create_kv_response"))

    candidates = [
        {
            "ritm_number": body.get("ritm_number"),
            "catalog_task_sysid": body.get("catalog_task_sysid"),
        },
        body.get("request_parameters") or {},
        input_payload.get("request_parameters") or {},
        parsed_kv_output.get("request_parameters") or {},
        raw_kv_response.get("request_parameters") or {},
        trigger_payload.get("request_parameters") or {},
        create_kv_input.get("request_parameters") or {},
        create_kv_response.get("request_parameters") or {},
    ]

    for candidate in candidates:
        if isinstance(candidate, dict) and candidate.get("ritm_number") and candidate.get("catalog_task_sysid"):
            return candidate

    for candidate in candidates:
        if isinstance(candidate, dict) and candidate:
            return candidate

    return {}


def _determine_status_code(validation_result: dict) -> int:
    return 200 if validation_result.get("status") == "success" else 400


def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        body = req.get_json()
    except ValueError:
        return func.HttpResponse(
            json.dumps({"error": "Invalid JSON"}),
            status_code=400,
            mimetype="application/json"
        )

    request_params = _extract_request_params(body)

    ritm_number = request_params.get("ritm_number", "unknown")
    catalog_task_sysid = request_params.get("catalog_task_sysid", "unknown")

    validation_result = validate_kv(body)
    status_code = _determine_status_code(validation_result)

    if validation_result.get("status") == "success":
        validation_result["message"] = "KeyVault created successfully"
    else:
        errors = validation_result.get("errors", [])
        reason = "; ".join(errors) if errors else "unknown reason"
        validation_result["message"] = f"KeyVault creation failed, because of {reason}"

    store_monitor_result(ritm_number, catalog_task_sysid, validation_result)

    return func.HttpResponse(
        json.dumps(validation_result, indent=2),
        status_code=status_code,
        mimetype="application/json"
    )
