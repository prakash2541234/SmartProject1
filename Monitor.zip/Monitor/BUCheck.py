# monitor 7 - validate backup deployment flow and store results in Table Storage

import json
import os
import logging
import azure.functions as func
from azure.data.tables import TableServiceClient, UpdateMode


# -------------------------------
# Utility Functions
# -------------------------------

def is_missing(value):
    return value is None or value == ""


def validate_backup(data: dict) -> dict:
    result = {
        "status": "success",
        "errors": [],
        "missing_fields": {},
        "details": {}
    }

    # 🔹 Extract output
    backup_status = data.get("backup_status")
    backup_message = data.get("backup_message")

    # 🔹 Extract input payload
    input_payload = data.get("input_payload", {})

    fields = {
        "subscription_id": input_payload.get("subscription_id"),
        "appid": input_payload.get("appid"),
        "environment": input_payload.get("environment"),
        "region": input_payload.get("region"),
        "redundancy": input_payload.get("redundancy"),
        "support_email": input_payload.get("support_email")
    }

    # 🔹 Validate backup output
    if is_missing(backup_status):
        result["status"] = "failed"
        result["errors"].append("backup_status is missing")

    elif backup_status != "success":
        result["status"] = "failed"
        result["errors"].append(f"Backup deployment failed with status: {backup_status}")

    if is_missing(backup_message):
        result["status"] = "failed"
        result["errors"].append("backup_message is missing")

    # 🔹 Validate input fields
    for key, value in fields.items():
        if is_missing(value):
            result["status"] = "failed"
            result["missing_fields"][key] = True
            result["errors"].append(f"{key} is missing")
        else:
            result["missing_fields"][key] = False

    # 🔹 Attach debug details
    result["details"] = {
        "backup_status": backup_status,
        "backup_message": backup_message,
        "validated_inputs": fields
    }

    return result


# -------------------------------
# Storage Function (SAFE)
# -------------------------------

def store_monitor_result(ritm_number: str, catalog_task_sysid: str, result: dict) -> None:
    try:
        if not ritm_number or not catalog_task_sysid or ritm_number == "unknown" or catalog_task_sysid == "unknown":
            logging.error("❌ Missing PartitionKey or RowKey. Skipping table insert.")
            return

        connection_string = os.getenv("TABLE_STORAGE_CONNECTION_STRING","DefaultEndpointsProtocol=https;AccountName=subscriptioncreation;AccountKey=FxlHySGVXafXxHZRKs+9yZR06N4yMGjlXtHNe39ulajMmj5lR9sB2mJAvZqPX4AEaL/FZ95LjIIv+AStkOHRUg==;EndpointSuffix=core.windows.net")
        table_name = os.getenv("TABLE_STORAGE_MONITOR_TABLE_NAME", "subscriptioncreation")

        service = TableServiceClient.from_connection_string(conn_str=connection_string)
        table_client = service.get_table_client(table_name)

        entity = {
            "PartitionKey": ritm_number,
            "RowKey": catalog_task_sysid,
            "Monitor7": json.dumps(result)
        }

        table_client.upsert_entity(entity=entity, mode=UpdateMode.MERGE)

        logging.info(f"✅ Monitor7 stored | RITM={ritm_number}, SYSID={catalog_task_sysid}")

    except Exception as e:
        logging.error(f"❌ Table Storage Error: {str(e)}")


# -------------------------------
# FIXED Extraction Logic
# -------------------------------

def _extract_request_params(body: dict) -> dict:
    candidates = [
        {
            "ritm_number": body.get("ritm_number"),
            "catalog_task_sysid": body.get("catalog_task_sysid"),
        },
        body.get("request_parameters", {}),
        body.get("input_payload", {}).get("request_parameters", {}),
        body.get("backup_output", {}).get("request_parameters", {}),

        # ✅ FIXED: Add original_payload extraction
        body.get("original_payload", {}).get("request_parameters", {}),
    ]

    for candidate in candidates:
        if isinstance(candidate, dict) and candidate.get("ritm_number") and candidate.get("catalog_task_sysid"):
            return candidate

    return {}


def _determine_status_code(validation_result: dict) -> int:
    return 200 if validation_result.get("status") == "success" else 400


# -------------------------------
# MAIN FUNCTION
# -------------------------------

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        body = req.get_json()
    except ValueError:
        return func.HttpResponse(
            json.dumps({"error": "Invalid JSON"}),
            status_code=400,
            mimetype="application/json"
        )

    try:
        # 🔹 Extract identifiers
        request_params = _extract_request_params(body)

        ritm_number = request_params.get("ritm_number", "unknown")
        catalog_task_sysid = request_params.get("catalog_task_sysid", "unknown")

        logging.info(f"📌 Extracted -> RITM: {ritm_number}, SYSID: {catalog_task_sysid}")

        # 🔹 Validate backup
        validation_result = validate_backup(body)
        status_code = _determine_status_code(validation_result)

        # 🔹 Add message
        if validation_result.get("status") == "success":
            validation_result["message"] = "Backup created successfully"
        else:
            errors = validation_result.get("errors", [])
            reason = "; ".join(errors) if errors else "unknown reason"
            validation_result["message"] = f"Backup creation failed because: {reason}"

        # 🔹 Store result (safe)
        store_monitor_result(ritm_number, catalog_task_sysid, validation_result)

        return func.HttpResponse(
            json.dumps(validation_result, indent=2),
            status_code=status_code,
            mimetype="application/json"
        )

    except Exception as e:
        logging.error(f"❌ Unexpected Error: {str(e)}")

        return func.HttpResponse(
            json.dumps({
                "status": "failed",
                "error": str(e)
            }),
            status_code=500,
            mimetype="application/json"
        )