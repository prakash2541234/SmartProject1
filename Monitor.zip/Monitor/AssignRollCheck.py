#monitor 4 - validate AssignRole flow and store results in Table Storage

import json
import os
import logging
import azure.functions as func
from azure.data.tables import TableServiceClient, UpdateMode


def validate_parse_payload(parse_output: dict) -> list:
    required_fields = [
        "subscription_id",
        "subscription_access",
        "request_parameters",
        "status",
        "message"
    ]

    missing = []
    for field in required_fields:
        if field not in parse_output or parse_output.get(field) in [None, ""]:
            missing.append(field)

    return missing


def validate_assignroles_output(output: dict) -> list:
    required_fields = [
        "subscription_id",
        "subscription_access",
        "request_parameters"
    ]

    missing = []
    for field in required_fields:
        if field not in output or output.get(field) in [None, ""]:
            missing.append(field)

    return missing


def validate_assignroles_input(input_payload: dict) -> list:
    required_fields = [
        "subscription_id",
        "subscription_access",
        "request_parameters"
    ]

    missing = []
    for field in required_fields:
        if field not in input_payload or input_payload.get(field) in [None, ""]:
            missing.append(field)

    return missing


def store_monitor_result(ritm_number: str, catalog_task_sysid: str, result: dict) -> None:
    connection_string = os.getenv(
        "TABLE_STORAGE_CONNECTION_STRING",
        "DefaultEndpointsProtocol=https;AccountName=subscriptioncreation;AccountKey=FxlHySGVXafXxHZRKs+9yZR06N4yMGjlXtHNe39ulajMmj5lR9sB2mJAvZqPX4AEaL/FZ95LjIIv+AStkOHRUg==;EndpointSuffix=core.windows.net"
    )
    table_name = os.getenv("TABLE_STORAGE_MONITOR_TABLE_NAME", "subscriptioncreation")

    service = TableServiceClient.from_connection_string(conn_str=connection_string)
    table_client = service.get_table_client(table_name)

    entity = {
        "PartitionKey": ritm_number,
        "RowKey": catalog_task_sysid,
        "Monitor4": json.dumps(result)
    }

    table_client.upsert_entity(entity=entity, mode=UpdateMode.MERGE)
    logging.info(f"Monitor4 result stored for ritm={ritm_number}, catalog_sysid={catalog_task_sysid}")


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Validate AssignRole Payload function triggered.")

    try:
        body = req.get_json()
    except ValueError:
        return func.HttpResponse(
            json.dumps({
                "status": "failed",
                "message": "Invalid JSON input"
            }),
            status_code=400,
            mimetype="application/json"
        )

    parse_output = body.get("parse_assignrole_output", {})
    assignroles_output = body.get("call_assignroles_output", {})
    assignroles_input = body.get("call_assignroles_input", {})

    request_params = body.get("request_parameters", {})
    if not isinstance(request_params, dict) or not request_params:
        request_params = parse_output.get("request_parameters", {}) if isinstance(parse_output, dict) else {}
    if not isinstance(request_params, dict) or not request_params:
        request_params = assignroles_output.get("request_parameters", {}) if isinstance(assignroles_output, dict) else {}
    if not isinstance(request_params, dict) or not request_params:
        request_params = assignroles_input.get("request_parameters", {}) if isinstance(assignroles_input, dict) else {}

    ritm_number = request_params.get("ritm_number", "unknown")
    catalog_task_sysid = request_params.get("catalog_task_sysid", "unknown")

    # 🔹 Step 1: Validate ParseAssignRoleOutput
    parse_missing = validate_parse_payload(parse_output)

    if not parse_missing:
        result = {
            "status": "success",
            "message": "ParseAssignRoleOutput payload received correctly"
        }
        store_monitor_result(ritm_number, catalog_task_sysid, result)
        return func.HttpResponse(
            json.dumps(result),
            status_code=200,
            mimetype="application/json"
        )

    # 🔹 Step 2: Validate call_assignroles output
    output_missing = validate_assignroles_output(assignroles_output)

    if output_missing:
        # 🔹 Step 3: Validate input payload
        input_missing = validate_assignroles_input(assignroles_input)

        if input_missing:
            result = {
                "status": "failed",
                "error_stage": "call_assignroles_input",
                "message": "Input payload missing required fields",
                "missing_fields": input_missing
            }
            store_monitor_result(ritm_number, catalog_task_sysid, result)
            return func.HttpResponse(
                json.dumps(result),
                status_code=400,
                mimetype="application/json"
            )
        else:
            result = {
                "status": "failed",
                "error_stage": "call_assignroles_output",
                "message": "call_assignroles is not returning proper output",
                "missing_fields": output_missing
            }
            store_monitor_result(ritm_number, catalog_task_sysid, result)
            return func.HttpResponse(
                json.dumps(result),
                status_code=500,
                mimetype="application/json"
            )

    # 🔹 Fallback (unexpected case)
    result = {
        "status": "failed",
        "message": "Unknown validation error",
        "parse_missing_fields": parse_missing
    }
    store_monitor_result(ritm_number, catalog_task_sysid, result)
    return func.HttpResponse(
        json.dumps(result),
        status_code=500,
        mimetype="application/json"
    )