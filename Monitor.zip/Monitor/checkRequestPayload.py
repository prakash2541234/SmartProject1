#monitor 1 - validate incoming subscription creation payload and store results in Table Storage

import azure.functions as func
import logging
import json
import os
from datetime import datetime
from typing import Any, Dict, List
from azure.data.tables import TableServiceClient, UpdateMode


# =========================
# CONSTANTS (ALLOWED VALUES)
# =========================

ALLOWED_ENVIRONMENTS = {
    "prod", "poc",
    "dev", "test", "stage",
    "non prod", "non-prod",
    "development", "testing", "staging"
}

ALLOWED_SENSITIVITY = {
    "standard",
    "sensitive",
    "highly sensitive",
    "highlysensitive",
    "highly_sensitive",
    "highly-sensitive"
}

ALLOWED_NETWORK_MODEL = {
    "standalone",
    "onprem",
    "on-prem",
    "onprem_extension"
}


# =========================
# REQUIRED KEYS
# =========================

REQUIRED_TOP_LEVEL_KEYS = (
    "stla_parameters",
    "subscription_access",
    "az_parameters",
    "request_parameters",
)

REQUIRED_STLA_KEYS = (
    "application_id",
    "hle_usd",
    "support_email",
    "environment",
    "stla_global_business",
    "stla_global_subfunction",
    "sensitivity",
    "multi_tenant",
    "stla_region",
    "application_source",
    "application_name",
)

REQUIRED_SUBSCRIPTION_ACCESS_KEYS = ("manager", "standard", "view")
REQUIRED_NETWORK_CONFIG_KEYS = ("vnet", "region", "network_domain", "subnets")
REQUIRED_SUBNET_KEYS = ("fe", "be", "GatewaySubnet")
REQUIRED_REQUESTER_KEYS = ("first_name", "last_name", "user_id")


# =========================
# HELPERS
# =========================

def _is_non_empty_string(value: Any) -> bool:
    return isinstance(value, str) and value.strip() != ""


def _require_mapping(parent: Dict[str, Any], key: str, errors: List[str]) -> Dict[str, Any]:
    value = parent.get(key)
    if not isinstance(value, dict):
        errors.append(f"'{key}' must be an object.")
        return {}
    return value


def _require_list(parent: Dict[str, Any], key: str, errors: List[str]) -> List[Any]:
    value = parent.get(key)
    if not isinstance(value, list):
        errors.append(f"'{key}' must be an array.")
        return []
    return value


def _require_string(parent: Dict[str, Any], key: str, errors: List[str]) -> None:
    value = parent.get(key)
    if not _is_non_empty_string(value):
        errors.append(f"'{key}' is required and must be a non-empty string.")


def _require_bool(parent: Dict[str, Any], key: str, errors: List[str]) -> bool:
    value = parent.get(key)

    if isinstance(value, bool):
        return value

    if isinstance(value, str):
        if value.lower() == "true":
            parent[key] = True
            return True
        elif value.lower() == "false":
            parent[key] = False
            return False

    errors.append(f"'{key}' must be a boolean (true/false).")
    return False


def _validate_required_strings(parent: Dict[str, Any], keys: tuple[str, ...], errors: List[str]) -> None:
    for key in keys:
        _require_string(parent, key, errors)


# 🔥 NEW: Allowed value validation
def _validate_allowed_values(parent: Dict[str, Any], key: str, allowed: set, errors: List[str]) -> None:
    value = parent.get(key)

    if not _is_non_empty_string(value):
        errors.append(f"'{key}' must be a non-empty string.")
        return

    normalized = value.strip().lower()

    if normalized not in allowed:
        errors.append(
            f"Invalid value for '{key}': '{value}'. Allowed values are: {sorted(allowed)}"
        )
    else:
        parent[key] = normalized


# 🔥 NEW: Normalize environment
def normalize_environment(env: str) -> str:
    env = env.lower()

    if env in ("dev", "test", "stage", "non prod", "non-prod", "development", "testing", "staging"):
        return "nonprod"
    return env


# =========================
# MAIN VALIDATION FUNCTION
# =========================

def validate_process_create_sub_payload(payload: Any) -> Dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("Request payload must be a JSON object.")

    errors: List[str] = []

    # Top-level
    for key in REQUIRED_TOP_LEVEL_KEYS:
        if key not in payload:
            errors.append(f"Missing top-level object: '{key}'.")

    stla = _require_mapping(payload, "stla_parameters", errors)
    access = _require_mapping(payload, "subscription_access", errors)
    az = _require_mapping(payload, "az_parameters", errors)
    req = _require_mapping(payload, "request_parameters", errors)

    # =========================
    # STLA VALIDATION
    # =========================
    if stla:
        _validate_required_strings(stla, REQUIRED_STLA_KEYS, errors)

        _validate_allowed_values(stla, "environment", ALLOWED_ENVIRONMENTS, errors)
        _validate_allowed_values(stla, "sensitivity", ALLOWED_SENSITIVITY, errors)

        if "environment" in stla:
            stla["environment"] = normalize_environment(stla["environment"])

        _require_bool(stla, "multi_tenant", errors)

    # =========================
    # ACCESS VALIDATION
    # =========================
    if access:
        _validate_required_strings(access, REQUIRED_SUBSCRIPTION_ACCESS_KEYS, errors)

    # =========================
    # AZURE PARAMETERS
    # =========================
    if az:
        _validate_required_strings(az, ("azure_region", "network_domain", "network_model"), errors)

        _validate_allowed_values(az, "network_model", ALLOWED_NETWORK_MODEL, errors)

        # Network Config
        network_config = _require_list(az, "network_config", errors)
        if not network_config:
            errors.append("'network_config' must contain at least one item.")
        else:
            for i, item in enumerate(network_config):
                if not isinstance(item, dict):
                    errors.append(f"'network_config[{i}]' must be an object.")
                    continue

                _validate_required_strings(item, REQUIRED_NETWORK_CONFIG_KEYS[:-1], errors)

                subnets = _require_mapping(item, "subnets", errors)
                if subnets:
                    _validate_required_strings(subnets, REQUIRED_SUBNET_KEYS, errors)

        # Backup Config
        backup = _require_mapping(az, "backup_config", errors)
        if backup:
            if _require_bool(backup, "backup_enabled", errors):
                _validate_required_strings(
                    backup,
                    ("backup_replication_config", "replication_region"),
                    errors,
                )

        # SP Config
        sp = _require_mapping(az, "sp_config", errors)
        if sp:
            if _require_bool(sp, "sp_requested", errors):
                owners = sp.get("sp_owners")
                if not isinstance(owners, list) or not owners:
                    errors.append("'sp_owners' must be a non-empty list.")
                else:
                    for i, owner in enumerate(owners):
                        if not _is_non_empty_string(owner):
                            errors.append(f"'sp_owners[{i}]' must be a valid string.")

    # =========================
    # REQUEST PARAMETERS
    # =========================
    if req:
        _validate_required_strings(req, ("ritm_number", "catalog_task_sysid"), errors)

        requester = _require_mapping(req, "requester", errors)
        if requester:
            _validate_required_strings(requester, REQUIRED_REQUESTER_KEYS, errors)

    # =========================
    # FINAL
    # =========================
    if errors:
        raise ValueError("Payload validation failed: " + "; ".join(errors))

    return payload


# =========================
# TABLE STORAGE ROW CREATION
# =========================

def create_monitor_row(ritm_number: str, catalog_task_sysid: str, monitor1_result: dict) -> None:
    try:
        if not ritm_number or not catalog_task_sysid or ritm_number == "unknown" or catalog_task_sysid == "unknown":
            logging.error("Missing PartitionKey or RowKey. Skipping table insert.")
            return

        connection_string = os.getenv(
            "TABLE_STORAGE_CONNECTION_STRING","DefaultEndpointsProtocol=https;AccountName=subscriptioncreation;AccountKey=FxlHySGVXafXxHZRKs+9yZR06N4yMGjlXtHNe39ulajMmj5lR9sB2mJAvZqPX4AEaL/FZ95LjIIv+AStkOHRUg==;EndpointSuffix=core.windows.net")
        table_name = os.getenv("TABLE_STORAGE_MONITOR_TABLE_NAME", "subscriptioncreation")

        service = TableServiceClient.from_connection_string(conn_str=connection_string)
        service.create_table_if_not_exists(table_name=table_name)
        table_client = service.get_table_client(table_name)

        entity = {
            "PartitionKey": ritm_number,
            "RowKey": catalog_task_sysid,
            "CreatedTimestamp": datetime.utcnow().isoformat(),
            "Monitor1": json.dumps(monitor1_result)
        }

        table_client.upsert_entity(entity=entity, mode=UpdateMode.MERGE)
        logging.info(f"Monitor row created for ritm={ritm_number}, catalog_sysid={catalog_task_sysid}")
    except Exception as e:
        logging.error(f"Table Storage Error: {str(e)}")


def _extract_request_params(payload: Dict[str, Any]) -> Dict[str, Any]:
    candidates = [
        {
            "ritm_number": payload.get("ritm_number"),
            "catalog_task_sysid": payload.get("catalog_task_sysid"),
        },
        payload.get("request_parameters", {}),
    ]

    for candidate in candidates:
        if isinstance(candidate, dict) and candidate.get("ritm_number") and candidate.get("catalog_task_sysid"):
            return candidate

    return {}


# =========================
# AZURE FUNCTION ENTRY POINT
# =========================

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Processing subscription payload validation request...")

    try:
        payload = req.get_json()

        logging.info("Incoming payload:")
        logging.info(json.dumps(payload))

        request_params = _extract_request_params(payload)
        ritm_number = request_params.get("ritm_number", "unknown")
        catalog_task_sysid = request_params.get("catalog_task_sysid", "unknown")

        validated_payload = validate_process_create_sub_payload(payload)

        monitor1_result = {
            "status": "success",
            "message": "Payload validation successful",
            "request_parameters": validated_payload.get("request_parameters", {})
        }
        create_monitor_row(ritm_number, catalog_task_sysid, monitor1_result)

        return func.HttpResponse(
            json.dumps({
                "status": "success",
                "message": "Payload validation successful",
                "data": validated_payload
            }),
            status_code=200,
            mimetype="application/json"
        )

    except ValueError as ve:
        logging.error(f"Validation failed: {str(ve)}")

        payload = {}
        try:
            payload = req.get_json()
        except Exception:
            payload = {}

        request_params = _extract_request_params(payload) if isinstance(payload, dict) else {}
        ritm_number = request_params.get("ritm_number", "unknown")
        catalog_task_sysid = request_params.get("catalog_task_sysid", "unknown")

        monitor1_result = {
            "status": "failed",
            "message": f"Payload validation failed, because of {str(ve)}"
        }
        create_monitor_row(ritm_number, catalog_task_sysid, monitor1_result)

        return func.HttpResponse(
            json.dumps({
                "status": "failed",
                "message": f"Payload validation failed, because of {str(ve)}",
                "error_details": str(ve)
            }),
            status_code=400,
            mimetype="application/json"
        )

    except Exception as e:
        logging.exception("Unexpected error occurred")

        return func.HttpResponse(
            json.dumps({
                "status": "error",
                "error": "Internal server error",
                "details": str(e)
            }),
            status_code=500,
            mimetype="application/json"
        )