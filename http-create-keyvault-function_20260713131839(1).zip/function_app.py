import logging
import azure.functions as func
from azure.identity import DefaultAzureCredential
from azure.mgmt.keyvault import KeyVaultManagementClient
from azure.core.exceptions import HttpResponseError

app = func.FunctionApp()

@app.route(route="create-keyvault", methods=["POST"], auth_level=func.AuthLevel.FUNCTION)
def create_keyvault(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Processing Key Vault creation request.')

    try:
        req_body = req.get_json()
    except ValueError:
        return func.HttpResponse(
            '{"error": "Invalid JSON in request body."}',
            status_code=400,
            mimetype="application/json"
        )

    key_vault_name = req_body.get('keyVaultName')
    location = req_body.get('location')
    resource_group = req_body.get('resourceGroup')

    if not key_vault_name or not location or not resource_group:
        return func.HttpResponse(
            '{"error": "Missing required parameters: keyVaultName, location, resourceGroup."}',
            status_code=400,
            mimetype="application/json"
        )

    if not isinstance(key_vault_name, str) or not key_vault_name.strip():
        return func.HttpResponse(
            '{"error": "keyVaultName must be a non-empty string."}',
            status_code=400,
            mimetype="application/json"
        )

    if not isinstance(location, str) or not location.strip():
        return func.HttpResponse(
            '{"error": "location must be a non-empty string."}',
            status_code=400,
            mimetype="application/json"
        )

    if not isinstance(resource_group, str) or not resource_group.strip():
        return func.HttpResponse(
            '{"error": "resourceGroup must be a non-empty string."}',
            status_code=400,
            mimetype="application/json"
        )

    subscription_id = None
    try:
        credential = DefaultAzureCredential()
        subscription_id = credential.get_token("https://management.azure.com/.default").token
    except Exception as e:
        logging.error(f"Failed to obtain credential: {str(e)}")
        return func.HttpResponse(
            '{"error": "Failed to authenticate with Managed Identity."}',
            status_code=500,
            mimetype="application/json"
        )

    try:
        kv_client = KeyVaultManagementClient(credential, subscription_id)
    except Exception as e:
        logging.error(f"Failed to initialize Key Vault client: {str(e)}")
        return func.HttpResponse(
            '{"error": "Failed to initialize Key Vault management client."}',
            status_code=500,
            mimetype="application/json"
        )

    try:
        existing_vaults = kv_client.vaults.list_by_resource_group(resource_group)
        for vault in existing_vaults:
            if vault.name == key_vault_name:
                logging.info(f"Key Vault '{key_vault_name}' already exists.")
                return func.HttpResponse(
                    '{"message": "Key Vault already exists."}',
                    status_code=409,
                    mimetype="application/json"
                )
    except HttpResponseError as e:
        logging.error(f"Error checking existing vaults: {str(e)}")
        return func.HttpResponse(
            '{"error": "Failed to check existing Key Vaults."}',
            status_code=500,
            mimetype="application/json"
        )

    try:
        poller = kv_client.vaults.begin_create_or_update(
            resource_group_name=resource_group,
            vault_name=key_vault_name,
            parameters={
                "location": location,
                "properties": {
                    "tenant_id": credential.get_token("https://management.azure.com/.default").tenant_id,
                    "sku": {"family": "A", "name": "standard"},
                    "access_policies": []
                }
            }
        )
        vault = poller.result()
        logging.info(f"Key Vault '{key_vault_name}' created successfully.")
        return func.HttpResponse(
            '{"message": "Key Vault created successfully."}',
            status_code=201,
            mimetype="application/json"
        )
    except HttpResponseError as e:
        logging.error(f"Error creating Key Vault: {str(e)}")
        return func.HttpResponse(
            '{"error": "Failed to create Key Vault."}',
            status_code=500,
            mimetype="application/json"
        )
    except Exception as e:
        logging.error(f"Unexpected error: {str(e)}")
        return func.HttpResponse(
            '{"error": "An unexpected error occurred."}',
            status_code=500,
            mimetype="application/json"
        )